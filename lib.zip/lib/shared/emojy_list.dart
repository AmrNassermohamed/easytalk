

import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

class Emojy {
 static const  List <Emoji> emojy=[
   Emoji('heart', '❤️'),
   Emoji('heart', '❤️'),
   Emoji('heart', '❤️'),
   Emoji('heart', '❤️'),
   Emoji('heart', '❤️'),
 ];







}
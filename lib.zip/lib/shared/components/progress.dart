import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:translationchat/constants/colors.dart';



Widget progress(){

  return Center(
    child: CircularProgressIndicator(

      color:cyan,
    ),
  );

}